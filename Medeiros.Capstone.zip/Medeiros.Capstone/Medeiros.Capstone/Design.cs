﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Medeiros.Capstone
{
    class Design
    {
        public string ConvertOnesPlace(String num)
        {
            //Checks the number in the ones place
            //Implement cases for numbers 1 - 9
            // Have it return the number if only one number if two or more move number to tens contructor
            return null;
        }

        public string ConvertTensPlace(String num)
        {
            //Checks the number that is located in the tens place
            //Implement cases for 10 - 19 as well as 20, 30, etc.
            //Have it return the number if there are two numbers in the input if 3 or more move to last convererter constructor
            return null;
        }

        public string ConvertHundredsPlaceAndAbove(String num)
        {
            //Checks the rest of the numbers from the hundreds place to the billions
            //Implement cases using modulus to check if the number is up to hundred, thusand, million, etc. 
            //Leave blank cases in between to ensure that the program can display enough numbers to get all the way to billions
            //Example: 1,000,000/7 = a 6 digit number + 1 to the spot is in the millions place.
            return null;
        }


        //Non-Functional Requirements
        //Ensure that there is a textbox for the user to enter the number
        //Have an exit button 
        //Have a clear button to clear the box so the user can enter another number
        //Ensure that there is clarity as to where each button is

        //Functional Requirements
        //Ensure that there is a space in betweeen each word in the conversion to ensure that the number is easy to read
        //Have methods that stop the conversion once it is finished without it needing to check the remaining methods
        //Use modulus + 1 to check for the place the number begins in to save lines of code
    }
}
