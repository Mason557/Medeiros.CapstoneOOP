﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medeiros.Capstone
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string ConvertOnesPlace(String num)
        {

            int numberinput = Convert.ToInt32(num);
            String numbervalue = "";

            switch (numberinput)
            {
                case 1:
                    numbervalue = "One";
                    break;
                case 2:
                    numbervalue = "Two";
                    break;
                case 3:
                    numbervalue = "Three";
                    break;
                case 4:
                    numbervalue = "Four";
                    break;
                case 5:
                    numbervalue = "Five";
                    break;
                case 6:
                    numbervalue = "Six";
                    break;
                case 7:
                    numbervalue = "Seven";
                    break;
                case 8:
                    numbervalue = "Eight";
                    break;
                case 9:
                    numbervalue = "Nine";
                    break;
            }
            return numbervalue;
        }

        public string ConvertTensPlace(String num)
        {
            int numberinput = Convert.ToInt32(num);
            String numbervalue = "";

            switch (numberinput)
            {
                case 10:
                    numbervalue = "Ten";
                    break;
                case 11:
                    numbervalue = "Eleven";
                    break;
                case 12:
                    numbervalue = "Twelve";
                    break;
                case 13:
                    numbervalue = "Thirteen";
                    break;
                case 14:
                    numbervalue = "Fourteen";
                    break;
                case 15:
                    numbervalue = "Fifteen";
                    break;
                case 16:
                    numbervalue = "Sixteen";
                    break;
                case 17:
                    numbervalue = "Seventeen";
                    break;
                case 18:
                    numbervalue = "Eighteen";
                    break;
                case 19:
                    numbervalue = "Nineteen";
                    break;
                case 20:
                    numbervalue = "Twenty";
                    break;
                case 30:
                    numbervalue = "Thirty";
                    break;
                case 40:
                    numbervalue = "Forty";
                    break;
                case 50:
                    numbervalue = "Fifty";
                    break;
                case 60:
                    numbervalue = "Sixty";
                    break;
                case 70:
                    numbervalue = "Seventy";
                    break;
                case 80:
                    numbervalue = "Eighty";
                    break;
                case 90:
                    numbervalue = "Ninety";
                    break;
                default:
                    if (numberinput > 0)
                    {
                        //Checks the number in the tens place to ensure that the tens place constructor needs to be used
                        //If brought to this constructor, this line of code checks both cases in order to print out the correct words on the users end 
                        numbervalue = ConvertTensPlace(num.Substring(0, 1) + "0") + " " + ConvertOnesPlace(num.Substring(1));
                    }
                    break;
            }
            return numbervalue;
        }

        public string ConvertHundredsPlaceAndAbove(String num)
        {
            string numbervalue = "";
            double hundredsinput = Convert.ToDouble(num);

            //Only runs if the program detects that there is a number in the hundreds place or above
            if (hundredsinput > 0)
            {
                int numberlength = num.Length;
                String hundredsplace = "";
                int numberposition = 0;
                //Checks to see if the number positions have been converted               
                bool placeconverted = false;

                switch (numberlength)
                {
                    case 1:
                        //Checks to see if the ones place has been converted
                        numbervalue = ConvertOnesPlace(num);
                        placeconverted = true;
                        break;
                    case 2:
                        //Checks to see if the tens place has been converted
                        numbervalue = ConvertTensPlace(num);
                        placeconverted = true;
                        break;
                    case 3:
                        //If the number only has one digit after the tens place the program assigns it to the hundreds place
                        numberposition = 1;
                        hundredsplace = "Hundred";
                        break;
                    case 4:
                    case 5:
                    case 6:
                        //Checks to see if the number is divisible by 4
                        //If it is the program assigns the number to the thousands place
                        numberposition = (numberlength % 4) + 1;
                        hundredsplace = "Thousand";
                        break;
                    case 7:
                    case 8:
                    case 9:
                        //Checks to see if the number is divisible by 7
                        //If it is the program assigns the number to the millions place
                        numberposition = (numberlength % 7) + 1;
                        hundredsplace = "Million";
                        break;
                    case 10:
                    case 11:
                    case 12:
                        //Checks to see if the number is divisible by 10
                        //If it is the program assigns the number to the billions place
                        numberposition = (numberlength % 10) + 1;
                        hundredsplace = "Billion";
                        break;
                    default:
                        //Ensures that this method only stops once the number is fully converted
                        placeconverted = true;
                        break;
                }
                if (!placeconverted)
                {
                    if (num.Substring(0, numberposition) != "0" && num.Substring(numberposition) != "0" && Convert.ToInt32(num.Substring(0,numberposition)) != 0)
                    {
                        numbervalue = ConvertHundredsPlaceAndAbove(num.Substring(0, numberposition)) + " " + hundredsplace + " " + ConvertHundredsPlaceAndAbove(num.Substring(numberposition));
                    }
                    else
                    {
                        numbervalue = ConvertHundredsPlaceAndAbove(num.Substring(0, numberposition)) + " " + ConvertHundredsPlaceAndAbove(num.Substring(numberposition));
                    }
                }

            }
            //Returns the converted number
            return numbervalue;
        }

        public string DecimalPlace(String num)
        {
            String NumberBeforeDecimal = "";
            String DecimalResult = "";
            String DecimalPoint = "";
            String DecimalConversion = "";
            String DollarToDecimal = "";
            String SeperateDecimal = "";
            String Dollars = "";

            int decimalPlace = num.IndexOf(".");
            if (decimalPlace > 0)
            {
                //Takes and converts any number before the decimal place
                NumberBeforeDecimal = num.Substring(0, decimalPlace);
                //Looks for the decimal place and adds 1 to check numbers after
                DecimalPoint = num.Substring(decimalPlace + 1);
                //If there is a value in the decimal position, it converts it
                if(Convert.ToInt32(DecimalPoint) > 0)
                {
                    //Puts in identifers such as dollars and cents
                    Dollars = "Dollars";
                    DollarToDecimal = "and";
                    SeperateDecimal = "Cents";
                    //Converted decimal taken from other method
                    DecimalResult = DecimalToWords(DecimalPoint);
                }
            }
            //Formats the output so that everything displays in the correct order
            DecimalConversion = String.Format(" {0} {1} {2} {3} {4}", ConvertHundredsPlaceAndAbove(NumberBeforeDecimal),  Dollars, DollarToDecimal, DecimalResult, SeperateDecimal);
            return DecimalConversion;
        }

       //Method that converts the decimal
        public String DecimalToWords(String num)
        {
            String NumberOfDigits = "";
            String ConvertedDecimal = "";
            String ValueOfDecimal = "";

            for (int i = 0; i < num.Length; i++)
            {
                NumberOfDigits = num[i].ToString();
                if (NumberOfDigits.Equals("0"))
                {
                    //If no numbers after decimal, there is no conversion
                    ValueOfDecimal = "Zero";
                }
                else
                {
                    //If there are numbers after decimal it gets converted
                    ValueOfDecimal = ConvertOnesPlace(NumberOfDigits);
                }
                ConvertedDecimal += " " + ValueOfDecimal;
            }
            //Returns the decimal to be used in the above method to output it
            return ConvertedDecimal;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = DecimalPlace(textBox1.Text) + " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            label1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
